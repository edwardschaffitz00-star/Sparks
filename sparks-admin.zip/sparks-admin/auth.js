(function () {
  const cfg = window.SPARKS_SUPABASE || {};
  const ready =
    cfg.url &&
    cfg.anonKey &&
    !String(cfg.url).includes('YOUR_PROJECT_REF') &&
    cfg.anonKey !== 'YOUR_ANON_KEY';

  function loadClient() {
    if (!ready || !window.supabase) return null;
    if (!window.__sparksSb) {
      window.__sparksSb = window.supabase.createClient(cfg.url, cfg.anonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          storage: window.localStorage,
        },
      });
    }
    return window.__sparksSb;
  }

  async function getSession() {
    const sb = loadClient();
    if (!sb) return null;
    const { data } = await sb.auth.getSession();
    return data.session || null;
  }

  async function getProfile(userId) {
    const sb = loadClient();
    if (!sb || !userId) return null;
    const { data } = await sb
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    return data;
  }

  async function signup({ email, password, displayName }) {
    const sb = loadClient();
    if (!sb) throw new Error('Supabase is not configured yet.');
    const { data, error } = await sb.auth.signUp({
      email,
      password,
      options: {
        data: { display_name: displayName || '' },
        emailRedirectTo: window.location.origin + '/login',
      },
    });
    if (error) throw error;
    return data;
  }

  async function login({ email, password }) {
    const sb = loadClient();
    if (!sb) throw new Error('Supabase is not configured yet.');
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  }

  async function loginMagicLink(email) {
    const sb = loadClient();
    if (!sb) throw new Error('Supabase is not configured yet.');
    const { data, error } = await sb.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: window.location.origin + '/' },
    });
    if (error) throw error;
    return data;
  }

  async function logout() {
    const sb = loadClient();
    if (!sb) return;
    await sb.auth.signOut();
  }

  async function renderHomeAuth(opts) {
    const el = document.getElementById(opts?.mountId || 'auth-status');
    if (!el) return;
    if (!ready) {
      el.innerHTML =
        '<a class="auth-link" href="signup.html">Sign up</a>' +
        '<a class="auth-link" href="login.html">Log in</a>';
      return;
    }
    const session = await getSession();
    if (!session) {
      el.innerHTML =
        '<a class="auth-link" href="signup.html">Sign up</a>' +
        '<a class="auth-link" href="login.html">Log in</a>';
      return;
    }
    const profile = await getProfile(session.user.id);
    const isAdmin = !!(profile && profile.is_admin);
    const name = isAdmin
      ? 'The Algorithm'
      : (profile && profile.display_name) ||
        session.user.user_metadata?.display_name ||
        session.user.email?.split('@')[0] ||
        'Member';
    el.innerHTML =
      '<a class="auth-name" href="profile.html" style="text-decoration:none" title="' +
      escapeHtml(session.user.email || '') +
      '">' +
      escapeHtml(name) +
      '</a>' +
      (isAdmin
        ? '<a class="auth-link admin-pill" href="admin.html" title="Admin dashboard" style="margin-left:0">ADMIN</a>'
        : '') +
      '<button type="button" class="auth-link auth-btn" id="sparks-logout">Log out</button>';
    if (opts && typeof opts.onProfile === 'function') opts.onProfile(profile, session);
    const btn = document.getElementById('sparks-logout');
    if (btn) {
      btn.addEventListener('click', async () => {
        await logout();
        window.location.reload();
      });
    }
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  window.SparksAuth = {
    ready,
    loadClient,
    getSession,
    getProfile,
    signup,
    login,
    loginMagicLink,
    logout,
    renderHomeAuth,
  };
})();
