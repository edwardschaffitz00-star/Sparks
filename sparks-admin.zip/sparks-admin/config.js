// Public Supabase client config (anon key is safe to ship in the browser).
window.SPARKS_SUPABASE = {
  url: 'https://kiaihjyreftwsqycyrpt.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtpYWloanlyZWZ0d3NxeWN5cnB0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA2OTk5NDUsImV4cCI6MjEwNjI3NTk0NX0.N6Ip2vlaOfQwS-ChU-Vz-6UVDZS8pSiGzuuLzTaoj9k',
};
