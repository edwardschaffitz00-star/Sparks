-- SPARKS admin (chunk 4). Run in Supabase SQL editor.
-- Then: update public.profiles set is_admin = true where id = '<your-auth-user-uuid>';

create extension if not exists "pgcrypto";

alter table if exists public.profiles
  add column if not exists is_admin boolean not null default false,
  add column if not exists is_banned boolean not null default false,
  add column if not exists email text,
  add column if not exists last_sign_in_at timestamptz;

create or replace function public.is_sparks_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_admin and not p.is_banned
  );
$$;

create or replace function public.admin_list_users()
returns table (
  id uuid,
  display_name text,
  email text,
  city text,
  age int,
  avatar_url text,
  is_admin boolean,
  is_banned boolean,
  email_confirmed boolean,
  has_profile boolean,
  created_at timestamptz,
  last_sign_in_at timestamptz
)
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_sparks_admin() then
    raise exception 'not authorized';
  end if;

  return query
  select
    u.id,
    coalesce(p.display_name, split_part(coalesce(u.email, ''), '@', 1)),
    u.email,
    p.city,
    p.age,
    p.avatar_url,
    coalesce(p.is_admin, false),
    coalesce(p.is_banned, false),
    (u.email_confirmed_at is not null),
    (p.id is not null),
    coalesce(p.created_at, u.created_at),
    u.last_sign_in_at
  from auth.users u
  left join public.profiles p on p.id = u.id
  order by coalesce(p.created_at, u.created_at) desc;
end;
$$;

create or replace function public.admin_set_ban(target uuid, banned boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_sparks_admin() then
    raise exception 'not authorized';
  end if;
  if target = auth.uid() then
    raise exception 'cannot ban yourself';
  end if;
  update public.profiles set is_banned = banned where id = target;
end;
$$;

revoke all on function public.admin_list_users() from public;
revoke all on function public.admin_set_ban(uuid, boolean) from public;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.admin_set_ban(uuid, boolean) to authenticated;
grant execute on function public.is_sparks_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;

drop policy if exists admin_profiles_all on public.profiles;
create policy admin_profiles_all on public.profiles
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());

drop policy if exists admin_matches_all on public.matches;
create policy admin_matches_all on public.matches
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());

drop policy if exists admin_messages_all on public.messages;
create policy admin_messages_all on public.messages
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());

drop policy if exists admin_reports_all on public.reports;
create policy admin_reports_all on public.reports
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());
