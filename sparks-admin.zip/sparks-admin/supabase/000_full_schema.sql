-- SPARKS core schema + admin. Safe to re-run.
-- After this succeeds, run:
--   update public.profiles set is_admin = true where id = '<your auth.users uuid>';

create extension if not exists "pgcrypto";

-- ---------- TABLES ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  age int,
  city text,
  gender text,
  looking_for text,
  bio text,
  avatar_url text,
  is_admin boolean not null default false,
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists display_name text;
alter table public.profiles add column if not exists age int;
alter table public.profiles add column if not exists city text;
alter table public.profiles add column if not exists gender text;
alter table public.profiles add column if not exists looking_for text;
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles add column if not exists is_banned boolean not null default false;
alter table public.profiles add column if not exists created_at timestamptz not null default now();

create table if not exists public.likes (
  liker uuid not null references public.profiles(id) on delete cascade,
  likee uuid not null references public.profiles(id) on delete cascade,
  is_like boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (liker, likee)
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_a, user_b),
  check (user_a < user_b)
);

create table if not exists public.messages (
  id bigserial primary key,
  match_id uuid not null references public.matches(id) on delete cascade,
  sender uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id bigserial primary key,
  reporter uuid references public.profiles(id) on delete set null,
  reported uuid references public.profiles(id) on delete set null,
  reason text,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- Auto-create a match when both smash
create or replace function public.after_like()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  a uuid;
  b uuid;
begin
  if new.is_like and exists (
    select 1 from public.likes
    where liker = new.likee and likee = new.liker and is_like
  ) then
    a := least(new.liker, new.likee);
    b := greatest(new.liker, new.likee);
    insert into public.matches (user_a, user_b)
    values (a, b)
    on conflict (user_a, user_b) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists likes_after_like on public.likes;
create trigger likes_after_like
after insert or update on public.likes
for each row execute function public.after_like();

-- New auth user → profile row
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ---------- APP RPCs ----------
create or replace function public.discover_profiles(max_rows int default 20)
returns setof public.profiles
language sql
stable
security definer
set search_path = public
as $$
  select p.*
  from public.profiles p
  where p.id <> auth.uid()
    and coalesce(p.is_banned, false) = false
    and not exists (
      select 1 from public.likes l
      where l.liker = auth.uid() and l.likee = p.id
    )
  order by p.created_at desc
  limit greatest(1, least(coalesce(max_rows, 20), 50));
$$;

create or replace function public.my_matches()
returns table (
  match_id uuid,
  other_id uuid,
  other_name text,
  other_avatar text,
  other_is_admin boolean,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = public
as $$
  select
    m.id,
    case when m.user_a = auth.uid() then m.user_b else m.user_a end,
    case when p.is_admin then 'The Algorithm' else p.display_name end,
    p.avatar_url,
    coalesce(p.is_admin, false),
    m.created_at
  from public.matches m
  join public.profiles p
    on p.id = case when m.user_a = auth.uid() then m.user_b else m.user_a end
  where m.user_a = auth.uid() or m.user_b = auth.uid()
  order by m.created_at desc;
$$;

-- ---------- ADMIN ----------
create or replace function public.is_sparks_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_admin and not p.is_banned
  );
$$;

create or replace function public.admin_list_users()
returns table (
  id uuid,
  display_name text,
  email text,
  city text,
  age int,
  avatar_url text,
  is_admin boolean,
  is_banned boolean,
  email_confirmed boolean,
  has_profile boolean,
  created_at timestamptz,
  last_sign_in_at timestamptz
)
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_sparks_admin() then
    raise exception 'not authorized';
  end if;
  return query
  select
    u.id,
    coalesce(p.display_name, split_part(coalesce(u.email, ''), '@', 1)),
    u.email,
    p.city,
    p.age,
    p.avatar_url,
    coalesce(p.is_admin, false),
    coalesce(p.is_banned, false),
    (u.email_confirmed_at is not null),
    (p.id is not null),
    coalesce(p.created_at, u.created_at),
    u.last_sign_in_at
  from auth.users u
  left join public.profiles p on p.id = u.id
  order by coalesce(p.created_at, u.created_at) desc;
end;
$$;

create or replace function public.admin_set_ban(target uuid, banned boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_sparks_admin() then
    raise exception 'not authorized';
  end if;
  if target = auth.uid() then
    raise exception 'cannot ban yourself';
  end if;
  update public.profiles set is_banned = banned where id = target;
end;
$$;

revoke all on function public.admin_list_users() from public;
revoke all on function public.admin_set_ban(uuid, boolean) from public;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.admin_set_ban(uuid, boolean) to authenticated;
grant execute on function public.is_sparks_admin() to authenticated;
grant execute on function public.discover_profiles(int) to authenticated;
grant execute on function public.my_matches() to authenticated;

-- ---------- RLS ----------
alter table public.profiles enable row level security;
alter table public.likes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles
  for select to authenticated using (not is_banned or id = auth.uid() or public.is_sparks_admin());

drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles
  for insert to authenticated with check (id = auth.uid());

drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles
  for update to authenticated
  using (id = auth.uid() or public.is_sparks_admin())
  with check (id = auth.uid() or public.is_sparks_admin());

drop policy if exists profiles_delete_admin on public.profiles;
create policy profiles_delete_admin on public.profiles
  for delete to authenticated using (public.is_sparks_admin());

drop policy if exists likes_own on public.likes;
create policy likes_own on public.likes
  for all to authenticated
  using (liker = auth.uid() or public.is_sparks_admin())
  with check (liker = auth.uid() or public.is_sparks_admin());

drop policy if exists matches_own on public.matches;
create policy matches_own on public.matches
  for select to authenticated
  using (user_a = auth.uid() or user_b = auth.uid() or public.is_sparks_admin());

drop policy if exists admin_matches_all on public.matches;
create policy admin_matches_all on public.matches
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());

drop policy if exists messages_own on public.messages;
create policy messages_own on public.messages
  for all to authenticated
  using (
    public.is_sparks_admin()
    or exists (
      select 1 from public.matches m
      where m.id = match_id and (m.user_a = auth.uid() or m.user_b = auth.uid())
    )
  )
  with check (
    sender = auth.uid()
    and exists (
      select 1 from public.matches m
      where m.id = match_id and (m.user_a = auth.uid() or m.user_b = auth.uid())
    )
  );

drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports
  for insert to authenticated with check (reporter = auth.uid());

drop policy if exists reports_own_select on public.reports;
create policy reports_own_select on public.reports
  for select to authenticated using (reporter = auth.uid() or public.is_sparks_admin());

drop policy if exists admin_reports_all on public.reports;
create policy admin_reports_all on public.reports
  for all to authenticated
  using (public.is_sparks_admin())
  with check (public.is_sparks_admin());

-- Storage bucket for photos
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

drop policy if exists avatars_public_read on storage.objects;
create policy avatars_public_read on storage.objects
  for select using (bucket_id = 'avatars');

drop policy if exists avatars_own_write on storage.objects;
create policy avatars_own_write on storage.objects
  for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_own_update on storage.objects;
create policy avatars_own_update on storage.objects
  for update to authenticated
  using (bucket_id = 'avatars' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_sparks_admin()));

drop policy if exists avatars_own_delete on storage.objects;
create policy avatars_own_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'avatars' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_sparks_admin()));
