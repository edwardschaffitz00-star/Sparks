// Shared helpers for Sparks feature pages. Requires supabase-js, config.js, auth.js.
(function () {
  const ADMIN_NAME = 'The Algorithm';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Any admin is always shown as "The Algorithm" + ADMIN pill.
  function displayName(p) {
    if (p && p.is_admin) return ADMIN_NAME;
    return (p && p.display_name) || 'Member';
  }
  function nameHtml(p) {
    if (p && p.is_admin) return esc(ADMIN_NAME) + '<span class="admin-pill" title="Sparks admin">ADMIN</span>';
    return esc((p && p.display_name) || 'Member');
  }
  function avatarHtml(p, size) {
    const s = size || 44;
    const cls = 'sp-avatar' + (p && p.is_admin ? ' admin' : '');
    const style = 'width:' + s + 'px;height:' + s + 'px;font-size:' + Math.round(s * 0.4) + 'px';
    if (p && p.avatar_url) {
      return '<div class="' + cls + '" style="' + style + '"><img src="' + esc(p.avatar_url) + '" alt="" loading="lazy"></div>';
    }
    const initial = displayName(p).trim().charAt(0).toUpperCase() || '?';
    return '<div class="' + cls + '" style="' + style + '">' + esc(initial) + '</div>';
  }

  // True when an error means the 002 migration has not been run yet.
  function isMissingSchema(err) {
    if (!err) return false;
    const code = String(err.code || '');
    const msg = String(err.message || err);
    return ['42703', '42P01', '42883', 'PGRST200', 'PGRST202', 'PGRST204', 'PGRST205'].includes(code) ||
      /does not exist|schema cache|Could not find the (function|table)|Bucket not found/i.test(msg);
  }

  const SETUP_MSG =
    'This feature is almost ready — the Sparks database update has not been installed yet. ' +
    'Please check back soon.';

  function notice(el, html, kind) {
    if (!el) return;
    el.innerHTML = '<div class="sp-notice ' + (kind || '') + '">' + html + '</div>';
  }
  function showError(el, err) {
    if (isMissingSchema(err)) return notice(el, esc(SETUP_MSG));
    notice(el, esc((err && err.message) || 'Something went wrong. Please try again.'), 'err');
  }

  function client() {
    return window.SparksAuth ? SparksAuth.loadClient() : null;
  }

  // Resolve the logged-in session or show a login prompt.
  async function requireSession(el) {
    const sb = client();
    if (!sb) { notice(el, 'Sparks is not connected yet. Please try again later.', 'err'); return null; }
    const session = await SparksAuth.getSession();
    if (!session) {
      const next = encodeURIComponent(location.pathname + location.search);
      notice(el, 'You need to be logged in for this. <a href="login.html?next=' + next + '">Log in</a> or <a href="signup.html">sign up free</a>.');
      return null;
    }
    return session;
  }

  // Load my full profile; returns { profile, missing } where missing=true if the migration is not run.
  async function myProfile(userId) {
    const sb = client();
    const { data, error } = await sb.from('profiles').select('*').eq('id', userId).maybeSingle();
    if (error) return { profile: null, missing: isMissingSchema(error), error };
    const missing = !!data && !('is_admin' in data);
    return { profile: data, missing, error: null };
  }

  async function profilesByIds(ids) {
    const sb = client();
    const uniq = [...new Set(ids.filter(Boolean))];
    if (!uniq.length) return {};
    const { data } = await sb.from('profiles').select('id, display_name, avatar_url, is_admin, is_banned, age, city').in('id', uniq);
    const map = {};
    (data || []).forEach((p) => { map[p.id] = p; });
    return map;
  }

  function timeAgo(iso) {
    const d = new Date(iso);
    const s = (Date.now() - d.getTime()) / 1000;
    if (s < 60) return 'now';
    if (s < 3600) return Math.floor(s / 60) + 'm';
    if (s < 86400) return Math.floor(s / 3600) + 'h';
    if (s < 604800) return Math.floor(s / 86400) + 'd';
    return d.toLocaleDateString();
  }

  window.Sparks = {
    ADMIN_NAME, esc, displayName, nameHtml, avatarHtml, isMissingSchema, SETUP_MSG,
    notice, showError, client, requireSession, myProfile, profilesByIds, timeAgo,
  };
})();
